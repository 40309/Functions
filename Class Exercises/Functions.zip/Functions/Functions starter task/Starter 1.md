#Starter - Functions
These tasks are designed to refresh the reading and research you have undertaken at home prior to this lesson. If you have not completed the R&R assignment then please speak to your teacher before attempting these exercises.

##Structure tables and heirarchy charts

###Task 1
Arrange these sub-problems into the structure table outline provided.

|Sub-problems|Structure table|
|------------|:---------------:|
|`CALCULATE pay`|0|
|`INPUT number of hours worked, pay rate`|0.1|
|`CALCULATE basic pay`|0.2|
|`CALCULATE overtime pay`|0.2.1|
|`CALCULATE total pay`|0.2.2|
|`DISPLAY total pay`|0.3|

###Task 2
Complete this hierarchy chart for the above structure chart.

![](https://www.dropbox.com/s/2hcixuakpgbpwv4/Capture.PNG?dl=1)

###Task 3
What would a program do that was developed from the above structure table and hierarchy chart?

The program will allow for the user to input their number of hours that they work and then calculate their pay that they earn; which would obviously be their basic hours combined with any extra time that they do.

###Task 4

Write the program to calculate total pay using the above plan as your guide.

```python
print("This program will calculate the amount of money you earn")
print()
hourly_rate = float(input("Please enter the amount you gain per hour: "))
basic_hours = int(input("Please enter the number of hours that you work: "))
overtime = int(input("Please enter the overtime that you have worked: "))
basic_pay = hourly_rate * basic_hours
overtime_pay = hourly_rate * overtime
total_pay = basic_pay + overtime_pay

print("The total amount of money you have earned is £{0}".format(total_pay))
```