#**Test data**

|Hours|Pay rate|Expected result|Actual result|Did it match correctly?|
|:-----:|:-----:|:-----:|:-----:|:-----:|
|0|7.50|£0.00|£0.00|YES|
|100|7.50|£975.0|£975.0|YES|
|1|0|£0.00|£0.00|YES|
|orange|7.50|Error|ValueError|YES|
|hamza|99|Error|ValueError|YES|
|99|70|£8995|£8995|YES|




