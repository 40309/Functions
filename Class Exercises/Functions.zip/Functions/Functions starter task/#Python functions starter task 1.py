#Python functions starter task 1
#18/11/2014
#Hamza Butt

#calculate pay example

#defining the function calculating for basic pay
def calculate_basic_pay(hours,pay):
    basic_pay = hours * pay
    return basic_pay

#defining the function calculating for overtime pay
def calculate_overtime_pay(hours,pay):
   basic_pay = 40 * pay
   overtime_pay = (pay * 1.5) * (hours-40)
   total_pay_and_overtime = basic_pay + overtime_pay
   return total_pay_and_overtime

def calculate_total_pay(hours,pay):
    if hours<=40:
        total_pay = calculate_basic_pay(hours,pay)
    else:
        total_pay = calculate_overtime_pay(hours,pay)
    return total_pay

def work_details():
    hours = int(input("Please enter the number of hours that you work: "))
    pay = float(input("Please enter your rate of pay: £"))
    return hours,pay

def display_total_pay(total_pay):
    print("Your total wages are £{0}".format(total_pay))

def calculate_pay():
    hours,pay = work_details()
    total_pay = calculate_total_pay(hours,pay)
    display_total_pay(total_pay)
