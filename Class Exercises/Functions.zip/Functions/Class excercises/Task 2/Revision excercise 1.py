#01/12/2014
#Hamza Butt
#Functions class excercises - revision excercise 1

