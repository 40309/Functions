#Hamza Butt
#25/11/2014
#Task 1 - Functions - Part 1 - Improving a piece of code

def input_details():
    print("Times-table tester")
    print()
    table = int(input("Which times-table do you want to be tested on? "))
    return table

def loop1(table):
    import random
    for question in range(1,21):
       num1 = table
       num2 = random.randint(2,13)
       total = num1 * num2
       UserAnswer = input(str("{0} x {1} = ".format(num1,num2)))
       UserAnswer = int(UserAnswer)
       if UserAnswer == total:
           print('Well done, you got the correct answer!')
           print()
       else:
           print('Sorry, you got the answer wrong. The correct answer is',total)
           print()

def main():
    table = input_details()
    UserAnswer = loop1(table)


