#Hamza Butt
#25/11/2014
#Task 1 - Functions - Part 2 - Bank details

def input_details():
    first_n = input("Please enter your first name: ")
    last_n = input("Please enter your first name: ")
    gender = input("Please enter your gender: ")
    p_code = input("Please enter your post code: ")
    house_number = int(input("Please enter your house number: "))
    street_name = input("Please enter your street name: ")
    return first_n, last_n, gender, p_code, house_number

def title(gender):
    n_title = gender.upper()
    n_title = n_title[0]
    if n_title == "M":
        n_title = "Mr"
    elif n_title == "F":
        n_title = "Mrs"
    else:
        n_title = "Mx"
    return n_title

def display_details(n_title,first_n,last_n):    
    print("Welcome {0} {1} {2}. Thank you for registering with us.".format(n_title,first_n,last_n))

def main():
   print("First, we need to ask you some details")
   details = input_details()
   n_title = title(gender)
   display = display_details(n_title,first_n,last_n)
   
