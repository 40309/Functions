gender = input("please enter leetter")
n_title = gender.upper()
n_title = n_title[0]

print(n_title)
